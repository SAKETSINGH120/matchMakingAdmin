
// import * as React from "react";
// import { useEffect, useState, useCallback } from "react";
// import { useNavigate, useSearchParams } from "react-router-dom";
// import Breaker from "../../compoents/Breaker";
// import AOS from "aos";
// import "aos/dist/aos.css";
// import { getAllUsers, updateUserStatus } from "../../Services/userServices";
// import toast from "react-hot-toast";
// import ExportButton from "../../compoents/ExportButton";
// import getValFromSearchParams from "../../utils/getValFromSearchParams";
// import AddButton from "../../compoents/AddButton";
// import PaginationManager from "../../compoents/PaginationManager";
// import GenericTable from "../../compoents/Table";

// export default function UserList() {
//   const [searchParams, setSearchParams] = useSearchParams();

//   const { page, rowsPerPage } = getValFromSearchParams({ searchParams });

//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [totalPages, setTotalPages] = useState(0);
//   const [totalRecord, setTotalRecord] = useState(0);

//   const navigate = useNavigate();

//   const statusFilter = searchParams.get("status") || "active";

//   const capitalizeWords = (text) => {
//   if (!text) return "—";
//   return text
//     .toLowerCase()
//     .split(" ")
//     .map(word => word.charAt(0).toUpperCase() + word.slice(1))
//     .join(" ");
// };

//   useEffect(() => {
//     const currentPage = searchParams.get("page");
//     const currentLimit = searchParams.get("rowsPerPage");

//     if (!currentPage || !currentLimit) {
//       const newParams = new URLSearchParams(searchParams);

//       if (!currentPage) newParams.set("page", "1");
//       if (!currentLimit) newParams.set("rowsPerPage", "10");

//       setSearchParams(newParams);
//     }
//   }, []);

//   const fetchData = useCallback(async () => {
//     try {
//       setLoading(true);

//       const {
//         page: currentPage,
//         rowsPerPage: limit,
//         searchQueryFromUrl: searchQuery,
//       } = getValFromSearchParams({ searchParams });

//       const result = await getAllUsers({
//         page: currentPage,
//         rowsPerPage: limit,
//         searchQuery,
//         status: statusFilter || undefined,
//       });

//       if (result?.success) {
//         const transformedData = (result.data || []).map((item, index) => ({
//           id: item._id,
//           name: capitalizeWords(item.name),
//           number: item.number || "—",
//           gender: item.gender || "—",
//           isPremium: item.isPremium ? "Yes" : "No",
//           isVerified: item.isVerified ? "Yes" : "No",
//           activityScore: item.activityScore ?? 0,
//           status: item.status,
//           serialNo: index + 1 + (currentPage - 1) * limit,
//         }));

//         setData(transformedData);
//         setTotalPages(result.meta?.totalPages || 1);
//         setTotalRecord(result.meta?.total || result.data?.length || 0);
//       } else {
//         toast.error(result?.message || "Failed to fetch users.");
//       }
//     } catch (error) {
//       console.error("Error fetching users:", error);
//       toast.error("Error fetching users.");
//     } finally {
//       setLoading(false);
//     }
//   }, [searchParams, statusFilter]);

//   useEffect(() => {
//     fetchData();
//   }, [fetchData]);

//   useEffect(() => {
//     AOS.init({
//       duration: 1000,
//       once: true,
//     });
//   }, []);

//   const excelFileColumns = React.useMemo(() => {
//     return [
//       { label: "S.No", value: (row) => row?.serialNo || "" },
//       { label: "Name", value: (row) => row?.name || "" },
//       { label: "Number", value: (row) => row?.number || "" },
//       { label: "Gender", value: (row) => row?.gender || "" },
//       { label: "Premium", value: (row) => row?.isPremium || "" },
//       { label: "Verified", value: (row) => row?.isVerified || "" },
//       { label: "Activity Score", value: (row) => row?.activityScore || "" },
//       { label: "Status", value: (row) => row?.status || "" },
//     ];
//   }, []);

//   // const tableColumns = React.useMemo(() => {
//   //   return [
//   //     { label: "Name", key: "name" },
//   //     { label: "Number", key: "number" },
//   //     { label: "Gender", key: "gender" },
//   //     { label: "Premium", key: "isPremium" },
//   //     { label: "Verified", key: "isVerified" },
//   //     { label: "Activity Score", key: "activityScore" },
//   //     { label: "Status", key: "status" },
//   //   ];
//   // }, []);

//   const handleStatusUpdate = async (row) => {
//     try {
//       const action = row.status === "active" ? "block" : "unblock";

//       const result = await updateUserStatus(row.id, action);

//       if (result?.success) {
//         toast.success("Status updated successfully");



//         // setData((prevData) =>
//         //   prevData.map((item) =>
//         //     item.id === row.id
//         //       ? {
//         //           ...item,
//         //           status: row.status === "active" ? "blocked" : "active",
//         //         }
//         //       : item
//         //   )
//         // );

//         // 
//         fetchData();



//       } else {
//         toast.error(result?.message || "Failed to update");
//       }
//     } catch (error) {
//       toast.error("Error updating status");
//     }
//   };



//   const tableColumns = React.useMemo(() => {
//     return [
//       { label: "Name", key: "name" },
//       { label: "Number", key: "number" },
//       { label: "Gender", key: "gender" },
//       { label: "Premium", key: "isPremium" },
//       { label: "Verified", key: "isVerified" },
//       { label: "Activity Score", key: "activityScore" },

//       {
//         label: "Status",
//         key: "status",
//         render: (value, row) => (
//           <div className="flex items-center gap-3">

//             {/* Status Text */}
//             <span
//               className={`font-medium ${value === "active"
//                   ? "text-green-600"
//                   : "text-red-600"
//                 }`}
//             >
//               {value}
//             </span>

//             {/* Action Button */}
//             <button
//               onClick={() => handleStatusUpdate(row)}
//               className={`px-3 py-1 w-45px rounded text-white text-sm ${value === "active"
//                   ? "bg-red-500 hover:bg-red-600"
//                   : "bg-green-500 hover:bg-green-600"
//                 }`}
//             >
//               {value === "active" ? "Block" : "Unblock"}
//             </button>
//           </div>
//         ),
//       },
//     ];
//   }, [handleStatusUpdate]);

//   const handleAddClick = () => {
//     navigate("/users/create");
//   };

//   const handleView = (rowId) => {
//     console.log(rowId);
//     navigate(`view/${rowId}`);
//   };

//   const handleStatusChange = (e) => {
//     const newStatus = e.target.value;

//     setSearchParams((prev) => {
//       const next = new URLSearchParams(prev);
//       if (newStatus) {
//         next.set("status", newStatus);
//       } else {
//         next.delete("status");
//       }
//       next.set("page", "1");
//       return next;
//     });
//   };

//   return (
//     <div className="p-6 bg-gray-50 min-h-screen">
//       <div className="mb-6">
//         <Breaker />
//       </div>

//       <div className="flex justify-between items-center mb-8">
//         <h1 className="text-2xl font-bold text-gray-800">Users List</h1>

//         {/* <div className="flex gap-4">
//           <ExportButton
//             ariaLabel="Export Users"
//             dataToExport={data}
//             columns={excelFileColumns}
//             filename="users_list"
//           />

//           <AddButton btnName="Add User" onClick={handleAddClick} />
//         </div> */}
//       </div>

//       <div className="mb-6 flex items-center gap-4">
//         <label htmlFor="status-filter" className="font-medium text-gray-700">
//           Filter by Status:
//         </label>
//         <select
//           id="status-filter"
//           value={statusFilter}
//           onChange={handleStatusChange}
//           className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
//         >
//           <option value="active">Active</option>
//           <option value="blocked">Blocked</option>
//         </select>
//       </div>

//       <GenericTable
//         data={data}
//         columns={tableColumns}
//         hasAction={true}
//         hasEdit={false}
//         hasDelete={false}
//         hasView={true}
//         isLoading={loading}
//         ariaLabel="Users table"
//         limit={rowsPerPage}
//         page={page}
//         onView={(row) => handleView(row.id)}
//       />

//       <PaginationManager
//         rowsPerPage={rowsPerPage}
//         totalPages={totalPages}
//         totalRecord={totalRecord}
//         page={page}
//         setSearchParams={setSearchParams}
//         searchParams={searchParams}
//       />
//     </div>
//   );
// }

// import * as React from "react";
// import { useEffect, useState, useCallback } from "react";
// import { useNavigate, useSearchParams } from "react-router-dom";
// import Breaker from "../../compoents/Breaker";
// import AOS from "aos";
// import "aos/dist/aos.css";
// import { getAllUsers, updateUserStatus } from "../../Services/userServices";
// import toast from "react-hot-toast";
// import ExportButton from "../../compoents/ExportButton";
// import getValFromSearchParams from "../../utils/getValFromSearchParams";
// import AddButton from "../../compoents/AddButton";
// import PaginationManager from "../../compoents/PaginationManager";
// import GenericTable from "../../compoents/Table";

// export default function UserList() {
//   const [searchParams, setSearchParams] = useSearchParams();

//   const { page, rowsPerPage } = getValFromSearchParams({ searchParams });

//   const [data, setData] = useState([]);
//   const [loading, setLoading] = useState(false);
//   const [totalPages, setTotalPages] = useState(0);
//   const [totalRecord, setTotalRecord] = useState(0);
//   const [searchInput, setSearchInput] = useState(
//     searchParams.get("searchQuery") || ""
//   );

//   const navigate = useNavigate();

//   const statusFilter = searchParams.get("status") || "active";

//   const capitalizeWords = (text) => {
//     if (!text) return "—";
//     return text
//       .toLowerCase()
//       .split(" ")
//       .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
//       .join(" ");
//   };

//   useEffect(() => {
//     const currentPage = searchParams.get("page");
//     const currentLimit = searchParams.get("rowsPerPage");

//     if (!currentPage || !currentLimit) {
//       const newParams = new URLSearchParams(searchParams);

//       if (!currentPage) newParams.set("page", "1");
//       if (!currentLimit) newParams.set("rowsPerPage", "10");

//       setSearchParams(newParams);
//     }
//   }, []);

//   const fetchData = useCallback(async () => {
//     try {
//       setLoading(true);

//       const {
//         page: currentPage,
//         rowsPerPage: limit,
//         searchQueryFromUrl: searchQuery,
//       } = getValFromSearchParams({ searchParams });

//       // If searchQuery is present, ignore status filter
//       const searchAll = !!searchQuery;
//       const result = await getAllUsers({
//         page: currentPage,
//         rowsPerPage: limit,
//         searchQuery,
//         status: searchAll ? undefined : statusFilter || undefined,
//       });

//       if (result?.success) {
//         const transformedData = (result.data || []).map((item, index) => ({
//           id: item._id,
//           name: capitalizeWords(item.name),
//           number: item.number || "—",
//           gender: item.gender || "—",
//           isPremium: item.isPremium ? "Yes" : "No",
//           isVerified: item.isVerified ? "Yes" : "No",
//           activityScore: item.activityScore ?? 0,
//           status: item.status,
//           serialNo: index + 1 + (currentPage - 1) * limit,
//         }));

//         setData(transformedData);
//         setTotalPages(result.meta?.totalPages || 1);
//         setTotalRecord(result.meta?.total || result.data?.length || 0);
//       } else {
//         toast.error(result?.message || "Failed to fetch users.");
//       }
//     } catch (error) {
//       console.error("Error fetching users:", error);
//       toast.error("Error fetching users.");
//     } finally {
//       setLoading(false);
//     }
//   }, [searchParams, statusFilter]);

//   useEffect(() => {
//     fetchData();
//   }, [fetchData]);

//   useEffect(() => {
//     AOS.init({
//       duration: 1000,
//       once: true,
//     });
//   }, []);

//   const excelFileColumns = React.useMemo(() => {
//     return [
//       { label: "S.No", value: (row) => row?.serialNo || "" },
//       { label: "Name", value: (row) => row?.name || "" },
//       { label: "Number", value: (row) => row?.number || "" },
//       { label: "Gender", value: (row) => row?.gender || "" },
//       { label: "Premium", value: (row) => row?.isPremium || "" },
//       { label: "Verified", value: (row) => row?.isVerified || "" },
//       { label: "Activity Score", value: (row) => row?.activityScore || "" },
//       { label: "Status", value: (row) => row?.status || "" },
//     ];
//   }, []);

//   const handleStatusUpdate = async (row) => {
//     try {
//       const action = row.status === "active" ? "block" : "unblock";

//       const result = await updateUserStatus(row.id, action);

//       if (result?.success) {
//         toast.success("Status updated successfully");
//         fetchData();
//       } else {
//         toast.error(result?.message || "Failed to update");
//       }
//     } catch (error) {
//       toast.error("Error updating status");
//     }
//   };

//   const tableColumns = React.useMemo(() => {
//     return [
//       { label: "Name", key: "name" },
//       { label: "Number", key: "number" },
//       { label: "Gender", key: "gender" },
//       { label: "Premium", key: "isPremium" },
//       { label: "Verified", key: "isVerified" },
//       { label: "Activity Score", key: "activityScore" },
//       {
//         label: "Status",
//         key: "status",
//         render: (value, row) => (
//           <div className="flex items-center gap-3">
//             <span
//               className={`font-medium ${value === "active" ? "text-green-600" : "text-red-600"
//                 }`}
//             >
//               {value}
//             </span>
//             <button
//               onClick={() => handleStatusUpdate(row)}
//               className={`px-3 py-1 w-45px rounded text-white text-sm ${value === "active"
//                 ? "bg-red-500 hover:bg-red-600"
//                 : "bg-green-500 hover:bg-green-600"
//                 }`}
//             >
//               {value === "active" ? "Block" : "Unblock"}
//             </button>
//           </div>
//         ),
//       },
//     ];
//   }, [handleStatusUpdate]);

//   const handleAddClick = () => {
//     navigate("/users/create");
//   };

//   const handleView = (rowId) => {
//     navigate(`view/${rowId}`);
//   };

//   const handleStatusChange = (e) => {
//     const newStatus = e.target.value;
//     setSearchParams((prev) => {
//       const next = new URLSearchParams(prev);
//       if (newStatus) {
//         next.set("status", newStatus);
//       } else {
//         next.delete("status");
//       }
//       next.set("page", "1");
//       return next;
//     });
//   };

//   // Debounced search handler
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       setSearchParams((prev) => {
//         const next = new URLSearchParams(prev);
//         if (searchInput.trim()) {
//           next.set("searchQuery", searchInput.trim());
//         } else {
//           next.delete("searchQuery");
//         }
//         next.set("page", "1");
//         return next;
//       });
//     }, 400);

//     return () => clearTimeout(timer);
//   }, [searchInput]);

//   const handleClearSearch = () => {
//     setSearchInput("");
//     setSearchParams((prev) => {
//       const next = new URLSearchParams(prev);
//       next.delete("searchQuery");
//       next.set("page", "1");
//       return next;
//     });
//   };

//   return (
//     <div className="p-6 bg-gray-50 min-h-screen">
//       <div className="mb-6">
//         <Breaker />
//       </div>

//       <div className="flex justify-between items-center mb-8">
//         <h1 className="text-2xl font-bold text-gray-800">Users List</h1>
//       </div>

//       <div className="mb-6 flex flex-wrap items-center gap-4">
//         {/* Status Filter */}
//         <label htmlFor="status-filter" className="font-medium text-gray-700">
//           Filter by Status:
//         </label>
//         <select
//           id="status-filter"
//           value={statusFilter}
//           onChange={handleStatusChange}
//           className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
//         >
//           <option value="active">Active</option>
//           <option value="blocked">Blocked</option>
//         </select>

//         {/* Search by Name */}
//         <div className="flex items-center gap-2 ml-auto">
//           <div className="relative">
//             <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
//               <svg
//                 xmlns="http://www.w3.org/2000/svg"
//                 className="h-4 w-4"
//                 fill="none"
//                 viewBox="0 0 24 24"
//                 stroke="currentColor"
//               >
//                 <path
//                   strokeLinecap="round"
//                   strokeLinejoin="round"
//                   strokeWidth={2}
//                   d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
//                 />
//               </svg>
//             </span>
//             <input
//               type="text"
//               id="search-name"
//               placeholder="Search by name..."
//               value={searchInput}
//               onChange={(e) => setSearchInput(e.target.value)}
//               className="pl-9 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
//             />
//           </div>
//           {searchInput && (
//             <button
//               onClick={handleClearSearch}
//               className="px-3 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-md text-sm transition-colors"
//             >
//               Clear
//             </button>
//           )}
//         </div>
//       </div>

//       {!loading && data.length === 0 && searchParams.get("searchQuery") ? (
//         <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-xl border border-gray-200 shadow-sm">
//           <svg
//             xmlns="http://www.w3.org/2000/svg"
//             className="h-16 w-16 text-gray-300 mb-4"
//             fill="none"
//             viewBox="0 0 24 24"
//             stroke="currentColor"
//           >
//             <path
//               strokeLinecap="round"
//               strokeLinejoin="round"
//               strokeWidth={1.5}
//               d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
//             />
//           </svg>
//           <h3 className="text-lg font-semibold text-gray-700 mb-1">
//             User does not exist
//           </h3>
//           <p className="text-gray-400 text-sm">
//             No user with the name{" "}
//             <span className="font-medium text-gray-600">
//               "{searchParams.get("searchQuery")}"
//             </span>{" "}
//             exists in the system.
//           </p>
//           <button
//             onClick={handleClearSearch}
//             className="mt-5 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded-md transition-colors"
//           >
//             Clear Search
//           </button>
//         </div>
//       ) : (
//         <GenericTable
//           data={data}
//           columns={tableColumns}
//           hasAction={true}
//           hasEdit={false}
//           hasDelete={false}
//           hasView={true}
//           isLoading={loading}
//           ariaLabel="Users table"
//           limit={rowsPerPage}
//           page={page}
//           onView={(row) => handleView(row.id)}
//         />
//       )}

//       <PaginationManager
//         rowsPerPage={rowsPerPage}
//         totalPages={totalPages}
//         totalRecord={totalRecord}
//         page={page}
//         setSearchParams={setSearchParams}
//         searchParams={searchParams}
//       />
//     </div>
//   );
// }
import * as React from "react";
import { useEffect, useState, useCallback } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Breaker from "../../compoents/Breaker";
import AOS from "aos";
import "aos/dist/aos.css";
import { getAllUsers, updateUserStatus } from "../../Services/userServices";
import toast from "react-hot-toast";
import getValFromSearchParams from "../../utils/getValFromSearchParams";
import PaginationManager from "../../compoents/PaginationManager";
import GenericTable from "../../compoents/Table";

export default function UserList() {
  const [searchParams, setSearchParams] = useSearchParams();

  const { page, rowsPerPage } = getValFromSearchParams({ searchParams });

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalPages, setTotalPages] = useState(0);
  const [totalRecord, setTotalRecord] = useState(0);
  const [searchInput, setSearchInput] = useState(
    searchParams.get("searchQuery") || ""
  );

  const navigate = useNavigate();

  const statusFilter = searchParams.get("status") || "all";

  const statusTabs = [
    { key: "all", label: "All" },
    { key: "active", label: "Active" },
    { key: "blocked", label: "Blocked" },
  ];

  const capitalizeWords = (text) => {
    if (!text) return "—";
    return text
      .toLowerCase()
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  useEffect(() => {
    const currentPage = searchParams.get("page");
    const currentLimit = searchParams.get("rowsPerPage");

    if (!currentPage || !currentLimit) {
      const newParams = new URLSearchParams(searchParams);
      if (!currentPage) newParams.set("page", "1");
      if (!currentLimit) newParams.set("rowsPerPage", "10");
      setSearchParams(newParams);
    }
  }, []);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);

      const {
        page: currentPage,
        rowsPerPage: limit,
        searchQueryFromUrl: searchQuery,
      } = getValFromSearchParams({ searchParams });

      const currentStatus = searchParams.get("status") || "all";

      const result = await getAllUsers({
        page: currentPage,
        rowsPerPage: limit,
        searchQuery,
        status: currentStatus === "all" ? undefined : currentStatus,
      });

      if (result?.success) {
        const transformedData = (result.data || []).map((item, index) => ({
          id: item._id,
          name: capitalizeWords(item.name),
          number: item.number || "—",
          gender: item.gender || "—",
          isPremium: item.isPremium ? "Yes" : "No",
          isVerified: item.isVerified ? "Yes" : "No",
          activityScore: item.activityScore ?? 0,
          status: item.status,
          serialNo: index + 1 + (currentPage - 1) * limit,
        }));

        setData(transformedData);
        setTotalPages(result.meta?.totalPages || 1);
        setTotalRecord(result.meta?.total || result.data?.length || 0);
      } else {
        toast.error(result?.message || "Failed to fetch users.");
      }
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Error fetching users.");
    } finally {
      setLoading(false);
    }
  }, [searchParams]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    AOS.init({ duration: 1000, once: true });
  }, []);

  const handleStatusUpdate = async (row) => {
    try {
      const action = row.status === "active" ? "block" : "unblock";
      const result = await updateUserStatus(row.id, action);
      if (result?.success) {
        toast.success("Status updated successfully");
        fetchData();
      } else {
        toast.error(result?.message || "Failed to update");
      }
    } catch (error) {
      toast.error("Error updating status");
    }
  };

  const tableColumns = React.useMemo(() => {
    return [
      { label: "Name", key: "name" },
      { label: "Number", key: "number" },
      { label: "Gender", key: "gender" },
      { label: "Premium", key: "isPremium" },
      { label: "Verified", key: "isVerified" },
      { label: "Activity Score", key: "activityScore" },
      {
        label: "Status",
        key: "status",
        render: (value, row) => (
          <div className="flex items-center gap-3">
            <span
              className={`font-medium ${value === "active" ? "text-green-600" : "text-red-600"
                }`}
            >
              {value}
            </span>
            <button
              onClick={() => handleStatusUpdate(row)}
              className={`px-3 py-1 rounded text-white text-sm ${value === "active"
                  ? "bg-red-500 hover:bg-red-600"
                  : "bg-green-500 hover:bg-green-600"
                }`}
            >
              {value === "active" ? "Block" : "Unblock"}
            </button>
          </div>
        ),
      },
    ];
  }, [handleStatusUpdate]);

  const handleStatusChange = (status) => {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      if (status === "all") {
        next.delete("status");
      } else {
        next.set("status", status);
      }
      next.set("page", "1");
      return next;
    });
  };

  // Debounced search
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchParams((prev) => {
        const next = new URLSearchParams(prev);
        if (searchInput.trim()) {
          next.set("searchQuery", searchInput.trim());
        } else {
          next.delete("searchQuery");
        }
        next.set("page", "1");
        return next;
      });
    }, 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const handleClearSearch = () => {
    setSearchInput("");
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.delete("searchQuery");
      next.set("page", "1");
      return next;
    });
  };

  const handleView = (rowId) => {
    navigate(`view/${rowId}`);
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="mb-6">
        <Breaker />
      </div>

      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-800">Users List</h1>
      </div>

      <div className="mb-6 flex flex-wrap items-center gap-4">

        {/* Status Tab Buttons */}
        <div className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl p-1 shadow-sm">
          {statusTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleStatusChange(tab.key)}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 ${statusFilter === tab.key
                  ? "bg-blue-500 text-white shadow-sm"
                  : "text-gray-500 hover:bg-gray-100"
                }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search by Name */}
        <div className="flex items-center gap-2 ml-auto">
          <div className="relative">
            <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
                />
              </svg>
            </span>
            <input
              type="text"
              id="search-name"
              placeholder="Search by name..."
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              className="pl-9 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
            />
          </div>
          {searchInput && (
            <button
              onClick={handleClearSearch}
              className="px-3 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-md text-sm transition-colors"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {!loading && data.length === 0 && searchParams.get("searchQuery") ? (
        <div className="flex flex-col items-center justify-center py-20 text-center bg-white rounded-xl border border-gray-200 shadow-sm">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-16 w-16 text-gray-300 mb-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z"
            />
          </svg>
          <h3 className="text-lg font-semibold text-gray-700 mb-1">
            User does not exist
          </h3>
          <p className="text-gray-400 text-sm">
            No user with the name{" "}
            <span className="font-medium text-gray-600">
              "{searchParams.get("searchQuery")}"
            </span>{" "}
            exists in the system.
          </p>
          <button
            onClick={handleClearSearch}
            className="mt-5 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded-md transition-colors"
          >
            Clear Search
          </button>
        </div>
      ) : (
        <GenericTable
          data={data}
          columns={tableColumns}
          hasAction={true}
          hasEdit={false}
          hasDelete={false}
          hasView={true}
          isLoading={loading}
          ariaLabel="Users table"
          limit={rowsPerPage}
          page={page}
          onView={(row) => handleView(row.id)}
        />
      )}

      <PaginationManager
        rowsPerPage={rowsPerPage}
        totalPages={totalPages}
        totalRecord={totalRecord}
        page={page}
        setSearchParams={setSearchParams}
        searchParams={searchParams}
      />
    </div>
  );
}