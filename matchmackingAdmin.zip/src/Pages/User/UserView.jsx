

// import * as React from "react";
// import { useEffect, useState } from "react";
// import { useParams, useNavigate } from "react-router-dom";
// import toast from "react-hot-toast";
// import { getUserById } from "../../Services/userServices";
// import Breaker from "../../compoents/Breaker";

// export default function UserView() {
//   const { id } = useParams();
//   const navigate = useNavigate();

//   const [user, setUser] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchUser = async () => {
//       if (!id) {
//         toast.error("No user ID provided");
//         navigate("/users");
//         return;
//       }

//       try {
//         setLoading(true);
//         const result = await getUserById(id);

//         if (result?.success) {
//           setUser(result.data);
//         } else {
//           toast.error(result?.message || "Failed to load user details");
//           navigate("/users");
//         }
//       } catch (err) {
//         console.error("Error fetching user:", err);
//         toast.error("Could not fetch user details");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUser();
//   }, [id, navigate]);

//   if (loading) {
//     return (
//       <div className="min-h-screen bg-gray-50/70 flex items-center justify-center">
//         <div className="text-lg font-medium text-gray-600 animate-pulse">
//           Loading user profile...
//         </div>
//       </div>
//     );
//   }

//   if (!user) {
//     return (
//       <div className="min-h-screen bg-gray-50/70 flex items-center justify-center">
//         <div className="text-xl font-medium text-red-600">User not found</div>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-gray-50/60 py-8 px-4 sm:px-6 lg:px-8">
//        <Breaker />
//       <div className="mx-auto max-w-7xl ">
//         {/* Back button + Breaker */}
        
//           {/* <button
//             onClick={() => navigate(-1)}
//             className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition"
//           >
//             ← Back to list
//           </button> */}
//           {/* <Breaker /> */}
       

//         {/* Main Card */}
//         <div className="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100 ">
//           {/* Header */}
//           <div className="bg-gradient-to-r from-indigo-600 to-indigo-500 px-6 py-7 text-white">
//             <h1 className="text-2xl font-bold tracking-tight">
//               {user.name || "—"}
//             </h1>
            
//             <p className="mt-1.5 text-indigo-100/95 font-medium">
//               {user.number || "—"}
//             </p>
//           </div>

//           {/* Content */}
//           <div className="p-6 sm:p-8 space-y-10">
//             <CompactSection title="Basic Information">
//               <InfoItem label="Gender" value={user.gender} />
//               <InfoItem label="Date of Birth" value={formatDate(user.dob)} />
//               <InfoItem label="Age" value={calculateAge(user.dob)} />
//               <InfoItem
//                 label="Height"
//                 value={user.heightCm ? `${user.heightCm} cm` : "—"}
//               />
//               <InfoItem label="Profession" value={user.profession} />
//               <InfoItem label="Company" value={user.company} />
//               <InfoItem label="Education" value={user.education} />
//             </CompactSection>

//             <CompactSection title="Preferences">
//               <InfoItem label="Interested In" value={user.preferences?.interestedIn} />
//               <InfoItem
//                 label="Age Range"
//                 value={
//                   user.preferences?.minAge && user.preferences?.maxAge
//                     ? `${user.preferences.minAge} – ${user.preferences.maxAge}`
//                     : "—"
//                 }
//               />
//               <InfoItem
//                 label="Max Distance"
//                 value={
//                   user.preferences?.maxDistanceKm
//                     ? `${user.preferences.maxDistanceKm} km`
//                     : "—"
//                 }
//               />
//             </CompactSection>

//             <CompactSection title="Lifestyle">
//               <InfoItem label="Drinking" value={user.lifestyle?.drinking} />
//               <InfoItem label="Smoking" value={user.lifestyle?.smoking} />
//               <InfoItem label="Workout" value={user.lifestyle?.workout} />
//               <InfoItem label="Diet" value={user.lifestyle?.diet} />
//             </CompactSection>

//             <CompactSection title="Relationship Goal">
//               <InfoItem label="Goal" value={user.relationshipGoal} />
//             </CompactSection>

//             <CompactSection title="Account Status">
//               <InfoItem label="Premium" value={user.isPremium ? "Yes" : "No"} />
//               <InfoItem label="Verified" value={user.isVerified ? "Yes" : "No"} />
//               <InfoItem label="Activity Score" value={user.activityScore ?? 0} />
//               <InfoItem
//                 label="Profile Completion"
//                 value={`${user.profileCompletionPercent ?? 0}%`}
//               />
//             </CompactSection>

//             <CompactSection title="Bio">
//               <p className="text-gray-700 leading-relaxed whitespace-pre-line">
//                 {user.bio || "No bio provided."}
//               </p>
//             </CompactSection>

//             <CompactSection title="Interests">
//               {user.interests?.length > 0 ? (
//                 <div className="flex flex-wrap gap-2">
//                   {user.interests.map((interest, idx) => (
//                     <span
//                       key={idx}
//                       className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-50 text-indigo-700 border border-indigo-100"
//                     >
//                       {interest}
//                     </span>
//                   ))}
//                 </div>
//               ) : (
//                 <span className="text-gray-500 italic">No interests listed</span>
//               )}
//             </CompactSection>

//             <CompactSection title="Languages">
//               {user.languages?.length > 0 ? (
//                 <div className="flex flex-wrap gap-2">
//                   {user.languages.map((lang, idx) => (
//                     <span
//                       key={idx}
//                       className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-700 border border-gray-200"
//                     >
//                       {lang}
//                     </span>
//                   ))}
//                 </div>
//               ) : (
//                 <span className="text-gray-500 italic">No languages listed</span>
//               )}
//             </CompactSection>

//             <CompactSection title="Location & Activity">
//               <InfoItem label="City" value={user.location?.city} />
//               <InfoItem label="Country" value={user.location?.country} />
//               <InfoItem label="Last Active" value={formatDateTime(user.lastActiveAt)} />
//               <InfoItem label="Joined" value={formatDateTime(user.createdAt)} />
//               <InfoItem label="Last Updated" value={formatDateTime(user.updatedAt)} />
//             </CompactSection>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// /* ──────────────────────────────────────────────── */
// /*               Smaller / Cleaner Components        */
// /* ──────────────────────────────────────────────── */

// function CompactSection({ title, children }) {
//   return (
//     <div className="space-y-4">
//       <h3 className="text-lg font-semibold text-gray-800 border-b border-gray-200 pb-2">
//         {title}
//       </h3>
//       <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-3 text-sm">
//         {children}
//       </div>
//     </div>
//   );
// }

// function InfoItem({ label, value }) {
//   return (
//     <div className="flex justify-between sm:justify-start sm:gap-4">
//       <dt className="font-medium text-gray-600 min-w-[110px]">{label}:</dt>
//       <dd className="text-gray-900">{value || "—"}</dd>
//     </div>
//   );
// }

// /* ──────────────────────────────────────────────── */
// /*                   Helpers (unchanged)             */
// /* ──────────────────────────────────────────────── */

// function formatDate(dateString) {
//   if (!dateString) return "—";
//   return new Date(dateString).toLocaleDateString("en-GB", {
//     day: "numeric",
//     month: "short",
//     year: "numeric",
//   });
// }

// function formatDateTime(dateString) {
//   if (!dateString) return "—";
//   return new Date(dateString).toLocaleString("en-GB", {
//     day: "numeric",
//     month: "short",
//     year: "numeric",
//     hour: "2-digit",
//     minute: "2-digit",
//   });
// }

// function calculateAge(dob) {
//   if (!dob) return "—";
//   const birthDate = new Date(dob);
//   const today = new Date();
//   let age = today.getFullYear() - birthDate.getFullYear();
//   const m = today.getMonth() - birthDate.getMonth();
//   if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
//     age--;
//   }
//   return age;
// }
import * as React from "react";
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { getUserById } from "../../Services/userServices";
import Breaker from "../../compoents/Breaker";
import { FaUser, FaBriefcase, FaHeart, FaLanguage } from "react-icons/fa";

export default function UserView() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      if (!id) {
        toast.error("No user ID provided");
        navigate("/users");
        return;
      }

      try {
        setLoading(true);
        const result = await getUserById(id);

        if (result?.success) {
          setUser(result.data);
        } else {
          toast.error(result?.message || "Failed to load user");
          navigate("/users");
        }
      } catch (err) {
        toast.error("Could not fetch user details");
      } finally {
        setLoading(false);
      }
    };

    fetchUser();
  }, [id, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-gray-500 animate-pulse text-lg">
          Loading user profile...
        </p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-red-500 text-lg font-semibold">User not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <Breaker />

      <div className="max-w-8xl mx-auto space-y-6">
        <button
          onClick={() => navigate(-1)}
          className="text-sm text-gray-600 hover:text-black mt-8 transition bg-[#5f6f5c]/70 hover:bg-[#5f6f5c] text-white px-3 py-2 rounded "
        >
          ← Back
        </button>
        {/* Profile Header */}
        <div className="bg-[#3f4f3c] mt-8 text-white rounded-2xl shadow-lg p-6 flex items-center gap-6">

          <div className="h-24 w-24 rounded-full bg-white text-indigo-600 flex items-center justify-center text-3xl font-bold ring-4 ring-white/40">
            {user.name?.charAt(0) || "U"}
          </div>

          <div className="flex-1">
            <h1 className="text-3xl font-bold">{user.name}</h1>
            <p className="opacity-80">{user.number}</p>

            <div className="flex gap-3 mt-3">
              {user.isVerified && (
                <span className="px-3 py-1 text-xs bg-green-500 rounded-full">
                  Verified
                </span>
              )}

              {user.isPremium && (
                <span className="px-3 py-1 text-xs bg-yellow-400 text-black rounded-full">
                  Premium
                </span>
              )}
            </div>
          </div>

          <div className="text-right">
            <p className="text-sm opacity-80">Activity Score</p>
            <p className="text-3xl font-bold">{user.activityScore ?? 0}</p>
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-2 gap-6">

          <Card title="Basic Info" icon={<FaUser />}>
            <Row label="Gender" value={user.gender} />
            <Row label="Age" value={calculateAge(user.dob)} />
            <Row label="Height" value={user.heightCm ? `${user.heightCm} cm` : null} />
            <Row label="Profession" value={user.profession} />
            <Row label="Company" value={user.company} />
          </Card>

          <Card title="Preferences" icon={<FaHeart />}>
            <Row label="Interested In" value={user.preferences?.interestedIn} />
            <Row
              label="Age Range"
              value={
                user.preferences?.minAge
                  ? `${user.preferences.minAge} - ${user.preferences.maxAge}`
                  : null
              }
            />
            <Row
              label="Max Distance"
              value={
                user.preferences?.maxDistanceKm
                  ? `${user.preferences.maxDistanceKm} km`
                  : null
              }
            />
          </Card>

          <Card title="Lifestyle" icon={<FaBriefcase />}>
            <Row label="Drinking" value={user.lifestyle?.drinking} />
            <Row label="Smoking" value={user.lifestyle?.smoking} />
            <Row label="Workout" value={user.lifestyle?.workout} />
            <Row label="Diet" value={user.lifestyle?.diet} />
          </Card>

          <Card title="Account" icon={<FaUser />}>
            <Row label="Premium" value={user.isPremium ? "Yes" : "No"} />
            <Row label="Verified" value={user.isVerified ? "Yes" : "No"} />
            <Row label="Joined" value={formatDateTime(user.createdAt)} />
            <Row label="Last Active" value={formatDateTime(user.lastActiveAt)} />
          </Card>

        </div>

       

        {/* Interests & Languages */}
        <div className="grid md:grid-cols-3 gap-6">

          <Card title="Interests" icon={<FaHeart />}>
            <TagList items={user.interests} />
          </Card>

          <Card title="Languages" icon={<FaLanguage />}>
            <TagList items={user.languages} />
          </Card>
          {/* Bio */}
          <Card title="Bio">
            <p className="text-gray-600 leading-relaxed">
              {user.bio || "No bio provided"}
            </p>
          </Card>
        </div>

      </div>
    </div>
  );
}

/* Components */

function Card({ title, icon, children }) {
  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-xl transition p-6">
      <div className="flex items-center gap-2 mb-4 text-[#5f6f5c]">
        {icon}
        <h3 className="font-semibold text-lg">{title}</h3>
      </div>

      <div className="space-y-3 text-sm">{children}</div>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between border-b pb-1">
      <span className="text-gray-500">{label}</span>
      <span className="font-medium">{value || "—"}</span>
    </div>
  );
}

function TagList({ items }) {
  if (!items?.length) return <p className="text-gray-400">None</p>;

  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item, i) => (
        <span
          key={i}
          className="px-3 py-1 text-xs bg-indigo-100 text-indigo-700 rounded-full hover:bg-indigo-200 transition"
        >
          {item}
        </span>
      ))}
    </div>
  );
}

/* Helpers */

function formatDateTime(date) {
  if (!date) return "—";
  return new Date(date).toLocaleString();
}

function calculateAge(dob) {
  if (!dob) return "—";
  const birthDate = new Date(dob);
  const today = new Date();

  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();

  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--;

  return age;
}