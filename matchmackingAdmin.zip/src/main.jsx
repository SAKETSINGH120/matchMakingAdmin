import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { AuthProvider } from './auth/AuthContext.jsx'
// import {Usercontextprovider} from './auth/Usercontextprovider.jsx'


createRoot(document.getElementById('root')).render(
   <AuthProvider>
      <App />
    </AuthProvider>

)
